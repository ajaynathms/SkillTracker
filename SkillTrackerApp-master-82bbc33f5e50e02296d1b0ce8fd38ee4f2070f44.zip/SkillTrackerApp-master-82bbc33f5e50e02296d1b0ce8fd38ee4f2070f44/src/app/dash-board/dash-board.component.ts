import { Component, OnInit, ViewChild } from '@angular/core';
import { Graph } from '../entities/graph';
import { Associate } from '../entities/associate';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { DashBoardService } from './dash-board.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Cards } from 'src/app/entities/cards';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css'],
  providers:[DashBoardService]
})
export class DashBoardComponent implements OnInit {
  loading=false;
  displayedColumns = ['Picture','Status','AssociateId','AssociateName','Phone','Email','actions'];

  cards:Cards[];
  graphValues:Graph[];
  items:number[];
  materialColors:string[];
  materialColorsSet2:string[];
  associates:Associate[];
  dataSource: MatTableDataSource<Associate>;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private sanitizer:DomSanitizer,private service:DashBoardService,public snackBar: MatSnackBar,) { 

  }

  ngOnInit() {
    this.materialColors=[];
    this.materialColorsSet2=[];
    this.materialColors=["#F44336","#E91E63","#9C27B0","#673AB7","#3F51B5","#2196F3","#03A9F4","#00BCD4","#009688","#4CAF50","#8BC34A","#CDDC39","#FFEB3B","#FFC107","#FF9800","#FF5722","#795548","#9E9E9E","#607D8B","#00ACC1","#7CB342","#F06292"];
    this.materialColorsSet2=["#fb8c00","#43a047","#e53935","#00acc1","#8e24aa",
    "#fb8c00","#43a047","#e53935","#00acc1","#8e24aa"]
    this.graphValues=[];
    this.cards=[];
    this.associates=[];
    this.dataSource = new MatTableDataSource(this.associates);


    this.getAll();
  }
  getAll()
  {
      this.loading=true;
      this.associates=[];
      this.service.getAll().subscribe(data=>{
      
  this.associates=data;
  this.dataSource = new MatTableDataSource(this.associates);
  this.dataSource.sort = this.sort;
  this.cards=[];
  this.graphValues=[];
  this.service.getDashboard().subscribe(data=>{
    
    
    this.cards=data.Cards;
    this.graphValues=data.Graph;
    this.loading=false;
    console.log("debv");

})});

  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }
  getUrl(base64:string)
  {
    return this.sanitizer.bypassSecurityTrustResourceUrl( base64);
  }
  delete(id)
  {
    this.service.deleteAssociate(id).subscribe(data=>{
      this.snackBar.open(data.Message, "Ok", {
        duration: 2000,
      });
      this.getAll();
    });
  }

}
