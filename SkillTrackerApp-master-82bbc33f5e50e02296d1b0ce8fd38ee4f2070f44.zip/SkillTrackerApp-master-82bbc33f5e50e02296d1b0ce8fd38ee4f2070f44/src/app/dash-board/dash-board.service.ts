import { HttpClient } from "@angular/common/http";
import { Observable, identity } from "rxjs";
import { Skill } from "../entities/skill";
import { environment } from "../../environments/environment";
import { Injectable } from "@angular/core";
import { ActionStatus } from "../entities/action-status";
import { Associate } from "../entities/associate";
import { Dashboard } from "src/app/entities/dashboard";

@Injectable()
export class DashBoardService {
    constructor(private http: HttpClient) { }

    getAll(): Observable<Associate[]> {

        return this.http.get<Associate[]>(environment.apiUrl + "GetAllAssociates");

    }
    getDashboard(): Observable<Dashboard> {

        return this.http.get<Dashboard>(environment.apiUrl + "getdashboard");

    }
    deleteAssociate(id:number): Observable<ActionStatus> {

        return this.http.post<ActionStatus>(environment.apiUrl + "DeleteAssociate?id="+id,{});

    }

}