export class Skill
{
    Id:number;
    Skill_Name:string;
}