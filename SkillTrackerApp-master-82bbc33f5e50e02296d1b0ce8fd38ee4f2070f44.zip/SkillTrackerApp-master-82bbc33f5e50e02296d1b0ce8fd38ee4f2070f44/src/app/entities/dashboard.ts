import { Graph } from "src/app/entities/graph";
import { Cards } from "src/app/entities/cards";

export class Dashboard
{
    Graph:Graph[];
    Cards:Cards[];
}