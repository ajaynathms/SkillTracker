export class Cards
{
    Title:string;
    Count:string;
}