export class ActionStatus
{
    Status:boolean;
    Message:string;
}