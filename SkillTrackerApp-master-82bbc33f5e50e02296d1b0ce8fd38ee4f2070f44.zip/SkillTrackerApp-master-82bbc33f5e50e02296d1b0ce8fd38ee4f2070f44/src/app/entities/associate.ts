import { AssociateSkill } from "src/app/entities/associate-skill";

export class Associate
{
    Id:number;
    AssociateId:string;
    AssociateName:string;
    Gender:string;
    Email:string;
    Phone:string;
    Status:string;
    Skills:AssociateSkill[];
    Level:number;
    Picture?:string;
    Remarks?:string;
    Others?:string;
    Strength?:string;
    Weakness?:string;
}