import { Skill } from "./skill";

export class AssociateSkill
{
    Id:number;
    Skill:Skill;
    Rating:number;
}