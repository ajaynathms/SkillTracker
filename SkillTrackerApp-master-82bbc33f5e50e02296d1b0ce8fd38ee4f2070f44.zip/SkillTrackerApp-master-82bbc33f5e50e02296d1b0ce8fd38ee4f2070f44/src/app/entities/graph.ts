export class Graph
{
    Title:string;
    Percentage:string;
}