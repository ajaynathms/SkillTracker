import { TestBed, async } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  MatButtonModule,
  MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatDatepickerModule,
  MatDatepicker, MatDividerModule, MatDialogModule,
  MatNativeDateModule, MatSortModule,
  MatRadioModule, MatTableModule, MatSnackBarModule,
  MatSelectModule, MatSliderModule,
  MatOptionModule, MatButtonToggleModule,
  MatSlideToggleModule, ErrorStateMatcher, ShowOnDirtyErrorStateMatcher, MatGridListModule, MatAutocomplete, MatAutocompleteModule, MatProgressBarModule
} from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing'

import { RouterModule } from '@angular/router';

import { SkillComponent } from './skill.component';
import { ComponentFixture } from '@angular/core/testing';
import { SkillService } from 'src/app/skill/skill.service';
import { Interceptor } from 'src/app/interceptor/Interceptor';

describe('SkillComponent', () => {
  let component: SkillComponent;
  let fixture: ComponentFixture<SkillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillComponent ],imports:[ BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule, HttpClientModule,
        MatMenuModule, MatAutocompleteModule,
        MatToolbarModule, MatDividerModule,
        MatIconModule,
        MatCardModule,
        BrowserAnimationsModule,
        MatFormFieldModule,
        MatInputModule, CdkTableModule, MatTableModule,
        MatDatepickerModule,
        MatNativeDateModule, MatDialogModule,
        MatRadioModule, MatSortModule, MatProgressBarModule,
        MatSelectModule, MatSliderModule,
        MatOptionModule, MatButtonToggleModule, MatSnackBarModule,
        MatSlideToggleModule, MatGridListModule, RouterModule, RouterTestingModule]
        ,providers:[SkillService,{
          provide: HTTP_INTERCEPTORS,
          useClass: Interceptor,
          multi: true
        }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillComponent);
    component = fixture.componentInstance;
   // fixture.detectChanges();
  });

  // it('should create the app', async(() => {
  //   expect(component).toBeTruthy();
  // }));
});
