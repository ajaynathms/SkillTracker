import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, NgForm, FormControl } from '@angular/forms';
import { AssociateSkill } from '../entities/associate-skill';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { AssociateService } from './associate.service';
import { SkillService } from 'src/app/skill/skill.service';
import { forEach } from '@angular/router/src/utils/collection';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-associate',
  templateUrl: './associate.component.html',
  styleUrls: ['./associate.component.css'],
  providers: [AssociateService, SkillService]
})
export class AssociateComponent implements OnInit {
  url = '../../assets/noimage.png';
  autoCtrl: FormControl = new FormControl();
  sub: any;
  Id: number;
  newSkill: string;
  viewOnly = false;
  ngOnInit() {
    this.newSkill = '';
    this.Id = 0;
    this.route
      .queryParams
      .subscribe(params => {
        if (params['id']) { this.Id = params['id']; }
        if (params['view']) { this.viewOnly = true; }
        this.initAssociate();

      });
  }
  loading = false;

  regiForm: FormGroup;

  skills: AssociateSkill[];
  filteredSkill: Observable<string[]>;
  options: string[];
  constructor(public snackBar: MatSnackBar, private router: Router, private fb: FormBuilder, private route: ActivatedRoute, private service: AssociateService, private skillService: SkillService) {




  }


  updateSkill() {


    this.createFilterSkill();
    this.filteredSkill = this.autoCtrl.valueChanges
      .pipe(
      startWith(''),
      map(val => this.filter(val))
      );
  }
  initAssociate() {
    this.loading = true;
    this.initForm();
    if (this.Id != undefined && this.Id != 0) {
      this.service.getById(this.Id).subscribe(data => {

        this.loading = false;
        this.regiForm.patchValue(
          {
            Id: data.Id,
            Associate_Id: data.AssociateId,
            AssociateName: data.AssociateName,
            Email: data.Email,
            Phone: data.Phone,
            Gender: data.Gender,
            Status: data.Status,
            Level: data.Level.toString(),
            Strength: data.Strength,
            Weakness: data.Weakness,
            Remarks: data.Remarks,
            Others: data.Others,
          }
        );
        this.url = data.Picture;
        this.initializeSkillList(data.Skills);
      });

    }
    else {
      this.loading = false;
      this.initializeSkillList([]);
    }


  }
  addNewSkill() {
    let found = false;
    this.skills.forEach(element => {
      if (element.Skill.Skill_Name === this.newSkill) {
        this.snackBar.open("Skill already mapped!", "Ok", {
          duration: 2000,
        });
        found = true;
      }
    });
    if (!found)
      this.skills.push({ Id: 0, Rating: 0, Skill: { Id: 0, Skill_Name: this.newSkill } });
  }

  initializeSkillList(skill: AssociateSkill[]) {

    this.skills = [];
    this.skillService.getAllSkill().subscribe(data => {
      data.forEach(element => {

        let checkArray = skill.filter(x => x.Skill.Id === element.Id);
        if (checkArray.length === 0) {
          this.skills.push({ Id: 0, Rating: 0, Skill: element });
        }
        else {
          this.skills.push(checkArray[0]);
        }
      });

    });

  }


  initForm() {
    this.regiForm = this.fb.group({
      'Id': [0, null],
      'AssociateName': [null, Validators.required],
      'Associate_Id': [null, Validators.required],
      'Gender': [null, Validators.required],
      'Phone': [null, Validators.required],
      'Remarks': [null],
      'Strength': [null],
      'Weakness': [null],
      'Others': [null],
      'Status': ['blue'],
      'Level': ["1"],
      'Email': [null, Validators.compose([Validators.required, Validators.email])]
    });
  }
  filter(val: string): string[] {
    return this.options.filter(option =>
      option.toLowerCase().includes(val.toLowerCase()));
  }

  createFilterSkill() {
    this.options = [];
    this.skills.forEach(element => {
      this.options.push(element.Skill.Skill_Name);
    });
  }

  // Executed When Form Is Submitted  
  onFormSubmit(form: NgForm) {

    this.service.update(
      {
        Id: this.regiForm.get("Id").value,
        AssociateName: this.regiForm.get("AssociateName").value,
        AssociateId: this.regiForm.get("Associate_Id").value,
        Gender: this.regiForm.get("Gender").value,
        Email: this.regiForm.get("Email").value,
        Level: this.regiForm.get("Level").value,
        Others: this.regiForm.get("Others").value,
        Phone: this.regiForm.get("Phone").value,
        Remarks: this.regiForm.get("Remarks").value,
        Skills: this.skills,
        Status: this.regiForm.get("Status").value,
        Strength: this.regiForm.get("Strength").value,
        Weakness: this.regiForm.get("Weakness").value,
        Picture: this.url,
      }
    ).subscribe(data => {
      this.snackBar.open(data.Message, "Ok", {
        duration: 2000,
      });
      if (data.Status) {
        this.router.navigate(['../home']);
      }

    });

  }

  onSelectFile(event) {

    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = reader.result;
        console.log(this.url);
      }
    }
  }

}
