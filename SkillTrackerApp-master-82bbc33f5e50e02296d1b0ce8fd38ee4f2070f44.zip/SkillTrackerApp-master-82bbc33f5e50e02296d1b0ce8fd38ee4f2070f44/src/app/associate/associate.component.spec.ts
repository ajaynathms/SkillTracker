import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  MatButtonModule,
  MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatDatepickerModule,
  MatDatepicker, MatDividerModule, MatDialogModule,
  MatNativeDateModule, MatSortModule,
  MatRadioModule, MatTableModule, MatSnackBarModule,
  MatSelectModule, MatSliderModule,
  MatOptionModule, MatButtonToggleModule,
  MatSlideToggleModule, ErrorStateMatcher, ShowOnDirtyErrorStateMatcher, MatGridListModule, MatAutocomplete, MatAutocompleteModule, MatProgressBarModule
} from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing'

import { RouterModule } from '@angular/router';
import { AssociateComponent } from './associate.component';
import { SearchPipe } from 'src/app/pipe/SearchPipe';
import { AssociateService } from 'src/app/associate/associate.service';
import { SkillService } from 'src/app/skill/skill.service';
import { Interceptor } from 'src/app/interceptor/Interceptor';

describe('AssociateComponent', () => {
  let component: AssociateComponent;
  let fixture: ComponentFixture<AssociateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociateComponent,SearchPipe ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule, HttpClientModule,
        MatMenuModule, MatAutocompleteModule,
        MatToolbarModule, MatDividerModule,
        MatIconModule,
        MatCardModule,
        BrowserAnimationsModule,
        MatFormFieldModule,
        MatInputModule, CdkTableModule, MatTableModule,
        MatDatepickerModule,
        MatNativeDateModule, MatDialogModule,
        MatRadioModule, MatSortModule, MatProgressBarModule,
        MatSelectModule, MatSliderModule,
        MatOptionModule, MatButtonToggleModule, MatSnackBarModule,
        MatSlideToggleModule, MatGridListModule, RouterModule, RouterTestingModule

      ],providers:[AssociateService, SkillService,{
        provide: HTTP_INTERCEPTORS,
        useClass: Interceptor,
        multi: true
      }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('add new skill should not fail', () => {
    component.newSkill="test";
    component.addNewSkill();
    expect(component.skills.length).toBeGreaterThan(0);
  });

  it('init associate should set value to form', () => {
    component.Id=1;
    component.initAssociate();
    expect(this.url).not.toBeNull();
  });

  it('filter should not fail', () => {
    component.options=["test"];
    expect(component.filter("test")).not.toBeNull();
  });
  it('create filter should add to options', () => {
    component.skills=[{Id:1,Rating:12,Skill:{Id:1,Skill_Name:"test"}}];
    component.createFilterSkill();
    expect(component.options.length).toBeGreaterThan(0);
  });

});
