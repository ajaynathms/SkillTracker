﻿using BusinessEntities;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.Migrations;
namespace DataAccessLayer
{
    public class SkillRepository
    {
        public IReadOnlyList<Skill> GetAllSkill()
        {
            using (var context = new SkillTrackerDbContext())
            {
                return context.Skills.ToList();
            }
        }


        public ActionResponse UpdateSkill(Skill skill)
        {
            using (var context = new SkillTrackerDbContext())
            {
                {
                    var id = skill.Id;
                    if (id == 0&& context.Skills.Where(x=>x.Skill_Name==skill.Skill_Name).Any())
                    {
                        return new ActionResponse { Status = false, Message = "Skill already exists!" };

                    }
                    context.Skills.AddOrUpdate(skill);
                    context.SaveChanges();
                    return new ActionResponse { Status = true, Message = id==0? "Skill added successfully!": "Skill updated successfully!" };
                }

            }
        }

        public ActionResponse DeleteSkill(long id)
        {
            using (var context = new SkillTrackerDbContext())
            {
                {
                    if (context.AssociateSkills.Where(x => x.Skill.Id == id).Any())
                    {
                        return new ActionResponse { Status = false, Message = "Unable to delete skill.It's mapped to associate!" };
                    }
                    context.Skills.Remove(context.Skills.Where(x=>x.Id==id).FirstOrDefault());
                    context.SaveChanges();
                    return new ActionResponse { Status = true, Message = "Skill deleted successfully!" };
                }

            }
        }
    }
}
