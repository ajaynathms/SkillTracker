﻿using BusinessEntities;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System;

namespace DataAccessLayer
{
    public class AssociateRepository
    {
        public IReadOnlyList<Associate> GetAllAssociates()
        {
            using (var context = new SkillTrackerDbContext())
            {
                return context.Associates.Include(x => x.Skills.Select(sk => sk.Skill)).ToList();
            }
        }

        public ActionResponse UpdateAssociates(Associate associate)
        {
            using (var context = new SkillTrackerDbContext())
            {
                {
                    if (context.Associates.Where(x => x.AssociateId == associate.AssociateId).Any()&&associate.Id==0)
                    {
                        return new ActionResponse { Status = false, Message =  "Associate Id already exist!" };

                    }
                    context.Entry(associate).State = associate.Id == 0 ? EntityState.Added : EntityState.Modified;
                    foreach (var assocaiteSkill in associate.Skills)
                    {
                        if (assocaiteSkill.Skill.Id == 0)
                        {
                            context.Entry(assocaiteSkill.Skill).State = EntityState.Added;
                        }
                        else {
                            context.Entry(assocaiteSkill.Skill).State = EntityState.Unchanged;

                        }

                        context.Entry(assocaiteSkill).State = assocaiteSkill.Id == 0 ? EntityState.Added : EntityState.Modified;

                    }
                    context.SaveChanges();
                    return new ActionResponse { Status = true, Message = associate.Id == 0 ? "Associate added successfully!" : "Associate updated successfully!" };
                }

            }
        }

        public ActionResponse DeleteAssociates(int id)
        {
            using (var context = new SkillTrackerDbContext())
            {
                {
                    var assocaite = context.Associates.Where(x => x.Id == id).FirstOrDefault();
                  ///////  assocaite.Skills.Clear();
                    context.AssociateSkills.RemoveRange(assocaite.Skills);
                    context.Associates.Remove(assocaite);
                    context.SaveChanges();
                    return new ActionResponse { Status = true, Message = "Associate deleted successfully!" };
                }

            }
        }
        public DashBoard GetDashBoard()
        {
            var result = new DashBoard();
            using (var context = new SkillTrackerDbContext())
            {
                var sumTotal = context.AssociateSkills.Any() ? context.AssociateSkills.Sum(x => x.Rating) : 0;
                var graph = new List< Graph>();
                foreach (var skill in context.AssociateSkills.Where(x => x.Rating > 0).GroupBy(x => x.Skill))
                {
                    graph.Add(new Graph { Title = skill.Key.Skill_Name, Percentage =(double) (skill.Sum(x => x.Rating) / Convert.ToDecimal(sumTotal)) * 100 });

                }
                result.Graph = graph;
                var cards = new List<Cards>();
                var totalAssociates = context.Associates.Count();
                cards.Add(new Cards { Title = "Registered Candidates", Count = totalAssociates.ToString() });

                cards.Add(new Cards { Title = "Female Candidates", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Gender == "f").Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString()+"%" });
                cards.Add(new Cards { Title = "Male Candidates", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Gender == "m").Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString() + "%" });

                cards.Add(new Cards { Title = "Candidates Freshers", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Level == 1).Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString() + "%" });

                cards.Add(new Cards { Title = "Candidates Rated", Count = context.Associates.Where(x => x.Skills.Any(s => s.Rating > 0)).Count().ToString() });

                var totalMales = context.Associates.Where(x => x.Gender == "m").Count();
                var totalFemales = context.Associates.Where(x => x.Gender == "f").Count();
                cards.Add(new Cards { Title = "Female Candidates Rated", Count = totalFemales == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Gender=="f"&& x.Skills.Any(s => s.Rating > 0)).Count() / Convert.ToDecimal(totalFemales)) * 100)).ToString() + "%" });
                cards.Add(new Cards { Title = "Male Candidates Rated", Count = totalMales == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Gender == "m" && x.Skills.Any(s => s.Rating > 0)).Count() / Convert.ToDecimal(totalMales)) * 100)).ToString() + "%" });



                cards.Add(new Cards { Title = "Level 1 Candidates", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Level == 1).Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString() + "%" });
                cards.Add(new Cards { Title = "Level 2 Candidates", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Level == 2).Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString() + "%" });
                cards.Add(new Cards { Title = "Level 3 Candidates", Count = totalAssociates == 0 ? "0%" : (Math.Round((context.Associates.Where(x => x.Level == 3).Count() / Convert.ToDecimal(totalAssociates)) * 100)).ToString() + "%" });

                result.Cards = cards;
                return result;
            }
        }
    }
}
