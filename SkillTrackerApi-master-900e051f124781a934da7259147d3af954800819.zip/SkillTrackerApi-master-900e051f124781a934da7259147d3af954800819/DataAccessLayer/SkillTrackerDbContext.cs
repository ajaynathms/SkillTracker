﻿using BusinessEntities;
using System.Data.Entity;
namespace DataAccessLayer
{
    public partial class SkillTrackerDbContext : DbContext
    {        public SkillTrackerDbContext()
            : base("name=SkillTrackerDbContext")
        {
           

        }

        public virtual DbSet<Associate> Associates { get; set; }
        public virtual DbSet<Skill> Skills { get; set; }
        public virtual DbSet<AssociateSkill> AssociateSkills { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            
        }
    }
}