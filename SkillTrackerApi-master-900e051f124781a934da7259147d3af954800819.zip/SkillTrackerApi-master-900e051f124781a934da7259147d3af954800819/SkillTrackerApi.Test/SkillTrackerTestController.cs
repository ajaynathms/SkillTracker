﻿using NUnit.Framework;
using BusinessEntities;
using System.IO;
using Newtonsoft.Json;
using System.Collections;
using System.Reflection;
using SkillTrackerApi.Controllers;
using System.Linq;
namespace SkillTrackerApi.Test
{
    [TestFixture]
    public class SkillTrackerTestController
    {
        public static IEnumerable TestSkillData
        {
            get
            {
                string FileLoc = @"MockData\Skill.json";
                string FilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "").Replace("\\bin\\Debug", "");
                var jsonText = File.ReadAllText(Path.Combine(FilePath, FileLoc));
                var skill = JsonConvert.DeserializeObject<Skill>(jsonText);
                yield return skill;
            }
        }
        

        [Test, TestCaseSource("TestSkillData")]
        public void TestProject(Skill skill)
        {
            SkillController controller = new SkillController();
            var addResult=controller.Post(skill);
            Assert.AreEqual("Skill added successfully!", addResult.Message);
            var allSkills = controller.Get();
            Assert.IsNotNull(allSkills);
            var currentSkill = allSkills.Where(x=>x.Skill_Name==skill.Skill_Name).FirstOrDefault();
            currentSkill.Skill_Name = string.Format(currentSkill.Skill_Name," test");
            var updateResult = controller.Post(currentSkill);
            Assert.AreEqual("Skill updated successfully!", updateResult.Message);
            var deleteResult = controller.Delete(currentSkill.Id);
            Assert.AreEqual("Skill deleted successfully!", deleteResult.Message);

            var associate = GetAssociate();


            AssociateController associateController = new AssociateController();
            Assert.IsNotNull(associateController.GetAllAssociates());
            var addAssociateStatus=associateController.UpdateAssociate(associate);
            Assert.AreEqual(true, addAssociateStatus.Status);
            Assert.IsNotNull(associateController.GetDashBoard());
            var deleteAssociateStatus = associateController.DeleteAssociate((int)associate.Id);
            Assert.AreEqual(true, deleteAssociateStatus.Status);
            foreach (var skillToBeDeleted in controller.Get().Where(x => x.Skill_Name == "test skill 12345"))
            {
                controller.Delete(skillToBeDeleted.Id);
            }

            //////ProjectUpdateResult pResult = new ProjectUpdateResult();
            //////UserUpdateResult u = AddUser();
            //////testProject.Manager_ID = u.user.User_ID;
            //////testProject.Manager_Name = u.user.First_Name + u.user.Last_Name;
            //////pResult = oController.Post(testProject);
            //////string message = pResult.status.Message;
            //////Assert.AreEqual("Project added successfully", message);
            //////testProject.Project_ID = pResult.project.Project_ID;
            //////Assert.AreEqual("Project updated successfully", oController.Post(testProject).status.Message);
            //////Assert.IsNotNull(oController.Get());

        }

        private Associate GetAssociate()
        {
            string FileLoc = @"MockData\Associate.json";
            string FilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase).Replace("file:\\", "").Replace("\\bin\\Debug", "");
            var jsonText = File.ReadAllText(Path.Combine(FilePath, FileLoc));
            return JsonConvert.DeserializeObject<Associate>(jsonText);
        }


    }
}
