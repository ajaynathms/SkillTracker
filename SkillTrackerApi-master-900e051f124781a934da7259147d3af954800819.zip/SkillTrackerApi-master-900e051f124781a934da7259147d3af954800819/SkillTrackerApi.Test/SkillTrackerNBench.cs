﻿using NBench;
using SkillTrackerApi.Controllers;

namespace SkillTrackerApi.Test
{
    class SkillTrackerNBench
    {
        private const string CounterName = "SkillTracker-GetSkill";
        private Counter addRunCounter;
        private int key;

        private const int AcceptableMinAddThroughput = 100;

        [PerfSetup]
        public void Setup(BenchmarkContext context)
        {
            addRunCounter = context.GetCounter(CounterName);
            key = 0;
        }
        [PerfBenchmark(NumberOfIterations = 500, RunMode = RunMode.Throughput, RunTimeMilliseconds = 600000, TestMode = TestMode.Measurement)]
        [CounterMeasurement(CounterName)]
        [CounterThroughputAssertion(CounterName, MustBe.GreaterThan, AcceptableMinAddThroughput)]
        public void GetAllUsersCounterThroughputBenchMark(BenchmarkContext context)
        {
            SkillController oController = new SkillController();
            oController.Get();
            addRunCounter.Increment();
        }
      
    }
}
