﻿using BusinessEntities;
using DataAccessLayer;
using System.Collections.Generic;

namespace BusinessLayer
{
    public class AssociateBl
    {
        AssociateRepository repo;
        public AssociateBl()
        {
            repo = new AssociateRepository();
        }

        public IReadOnlyList<Associate> GetAllAssociates()
        {
            return repo.GetAllAssociates();
        }

        public ActionResponse UpdateAssociates(Associate associate)
        {
            return repo.UpdateAssociates(associate);
        }

        public ActionResponse DeleteAssociates(int id)
        {
            return repo.DeleteAssociates(id);
        }
        public DashBoard GetDashBoard()
        {
            return repo.GetDashBoard();
        }
    }
}
