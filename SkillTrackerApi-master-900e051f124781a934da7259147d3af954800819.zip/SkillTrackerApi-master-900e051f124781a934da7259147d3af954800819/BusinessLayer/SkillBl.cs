﻿using BusinessEntities;
using DataAccessLayer;
using System.Collections.Generic;

namespace BusinessLayer
{
    public class SkillBl
    {
        SkillRepository repo;
        public SkillBl()
        {
            repo = new SkillRepository();
        }

        public IReadOnlyList<Skill> GetAllSkill()
        {
            return repo.GetAllSkill();
        }


        public ActionResponse UpdateSkill(Skill skill)
        {
            return repo.UpdateSkill(skill);
        }

        public ActionResponse DeleteSkill(long id)
        {
            return repo.DeleteSkill(id);
        }
    }
}
