﻿using BusinessEntities;
using BusinessLayer;
using System.Collections.Generic;
using System.Web.Http;

namespace SkillTrackerApi.Controllers
{
    public class SkillController : ApiController
    {

        SkillBl skillBl;
        public SkillController()
        {
            skillBl = new SkillBl();
        }
        // GET api/<controller>
        public IEnumerable<Skill> Get()
        {
            return skillBl.GetAllSkill();
        }


        // POST api/<controller>
        public ActionResponse Post([FromBody]Skill skill)
        {
            return skillBl.UpdateSkill(skill);
        }


        // DELETE api/<controller>/5
        public ActionResponse Delete(long id)
        {
            return skillBl.DeleteSkill(id);
        }
    }
}