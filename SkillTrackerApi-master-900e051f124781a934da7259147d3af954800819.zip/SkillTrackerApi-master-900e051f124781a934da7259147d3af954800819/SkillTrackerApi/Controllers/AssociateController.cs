﻿using BusinessEntities;
using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SkillTrackerApi.Controllers
{
    public class AssociateController : ApiController
    {
        AssociateBl associateBl;
        public AssociateController()
        {
            associateBl = new  AssociateBl();
        }

        [HttpGet]
        [Route("api/GetAllAssociates")]
        // GET api/<controller>
        public IEnumerable<Associate> GetAllAssociates()
        {
            return associateBl.GetAllAssociates();
        }

        [HttpGet]
        [Route("api/GetAssociatebyId")]
        // GET api/<controller>
        public Associate GetAssociatebyId(int id)
        {
            return associateBl.GetAllAssociates().Where(x => x.Id == id).FirstOrDefault();
        }

        [HttpPost]
        [Route("api/UpdateAssociate")]
        // GET api/<controller>
        public ActionResponse UpdateAssociate(Associate associate)
        {
            return associateBl.UpdateAssociates(associate);
        }

        [HttpPost]
        [Route("api/DeleteAssociate")]
        // GET api/<controller>
        public ActionResponse DeleteAssociate([FromUri] int id)
        {
            return associateBl.DeleteAssociates(id);
        }
        [HttpGet]
        [Route("api/GetDashBoard")]
        public DashBoard GetDashBoard()
        {
            return associateBl.GetDashBoard();
        }

    }
}