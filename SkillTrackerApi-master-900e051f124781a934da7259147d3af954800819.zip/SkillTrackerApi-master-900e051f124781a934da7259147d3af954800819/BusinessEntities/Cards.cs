﻿namespace BusinessEntities
{
    public class Cards
    {
        public string Title { get; set; }
        public string Count { get; set; }
    }
}
