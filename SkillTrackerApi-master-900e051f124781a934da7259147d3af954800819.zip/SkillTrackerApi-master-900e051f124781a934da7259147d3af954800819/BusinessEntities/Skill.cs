﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BusinessEntities
{
    [Table("Skill")]
    public class Skill
    {
        public Skill()
        {
        }
        [Key]
        public long Id { get; set; }
        [MaxLength(1000)]
        public string Skill_Name { get; set; }
    }
}
