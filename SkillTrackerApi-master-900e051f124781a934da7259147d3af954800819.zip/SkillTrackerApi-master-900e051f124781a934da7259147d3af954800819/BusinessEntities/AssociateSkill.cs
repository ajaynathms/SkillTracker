﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BusinessEntities
{
    [Table("AssociateSkill")]
    public class AssociateSkill
    {
        [Key]
        public long Id { get; set; }
        public int Rating { get; set; }
        public Skill Skill { get; set; }
      //////////////  public Associate Associate { get; set; }
    }
}
