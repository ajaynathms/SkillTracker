﻿using System.Collections.Generic;

namespace BusinessEntities
{
    public class Graph
    {
        public string Title { get; set; }
        public double Percentage { get; set; }
    }
}
