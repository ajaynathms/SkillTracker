﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BusinessEntities
{
    [Table("Associate")]
    public class Associate
    {
        public Associate()
        {
            Skills = new HashSet<AssociateSkill>();
        }
        [Key]
        public long Id { get; set; }
        public long AssociateId { get; set; }
        public string AssociateName { get; set; }
        [MaxLength(1)]
        public string Gender { get; set; }
        [MaxLength(50)]
        public string Email { get; set; }
        [MaxLength(50)]
        public string Phone { get; set; }
        public string Picture { get; set; }
        [MaxLength(5)]
        public string Status { get; set; }
        public int Level { get; set; }
        [MaxLength(5000)]
        public string Remark { get; set; }
        [MaxLength(5000)]
        public string Strength { get; set; }
        [MaxLength(5000)]
        public string Weakness { get; set; }
        public virtual ICollection<AssociateSkill> Skills { get; set; }
    }
}
