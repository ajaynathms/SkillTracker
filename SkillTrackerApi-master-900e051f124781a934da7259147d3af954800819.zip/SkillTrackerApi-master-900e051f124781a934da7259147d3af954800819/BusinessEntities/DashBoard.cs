﻿using System.Collections.Generic;

namespace BusinessEntities
{
    public class DashBoard
    {
        public List<Graph> Graph { get; set; }
        public List<Cards> Cards { get; set; }
    }
}
