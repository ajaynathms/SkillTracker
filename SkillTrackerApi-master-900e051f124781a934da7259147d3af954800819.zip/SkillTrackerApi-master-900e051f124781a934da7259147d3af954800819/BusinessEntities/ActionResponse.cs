﻿namespace BusinessEntities
{
    public class ActionResponse
    {
        public bool Status { get; set; }
        public string Message { get; set; }
    }
}
