Code Repos
APP- http://172.18.2.18/ajaynathms/SkillTrackerApp
API- http://172.18.2.18/ajaynathms/SkillTrackerApi

Pre- requisites
API- Please change the connection string in web.config. I have given sql login credentials as 
User Id: sa
Password: password1

Please change accordingly.

Use visual studio2017

APP- 

Run 
npm install
ng serve 

Navigate to http://localhost:4200/
For test and code coverage 

Run – ng test –code-coverage
Continuous Integration- Configured via Jenkins


IIS Sites 
App- http://localhost:9001/
Api- http://localhost:61734/

Code Coverage reports- 
Api- Uploaded to repo
App- Uploaded to repo.(Load the index.html file present app-coverage.zip)
All the reports are checked into this repo- http://172.18.2.18/ajaynathms/SkillTracker-Deliverables



